# 改修前への復元
改修前の公開版は Sites バージョン6。
完全なソースは Git commit `320940591dbfcabc453d0268a108edeea9dd5cb7` に保存済み。
そのコミットを別チェックアウトに復元して Sites の通常手順で再公開できる。
元のモデルは `dist/comparison/before-models.js` にも保持。
`/comparison.html` で元のモデルと改修後モデルを同一カメラ・照明で比較できる。

# 今回の変更
7ルートの内容・タイトル・ジオラマアニメーションは変更していない。
探索用の人物だけ、元のリグを使って肩・袖口・手・靴・カバン位置・顔の比率を調整。
レティクルは実際のパーツに子アンカーを付け、毎フレーム投影。メッシュへのレイで遮蔽を判定。
発見履歴はメモリのSetのみ。メダル完成で記録。通常の戻り操作では維持。
再読込、BFCache復帰、はじめから、window.exhibition.reset()、windowへのexhibition:startイベントで初期化。

# フォント差し替え
現状は端末の丸ゴシック（タイトル）、Noto Sans JP / ヒラギノ / Yu Gothic（本文）のフォールバック。フォントファイルを複製・配信していない。
`dist/typography.js` のtitleFamily/bodyFamilyを正規サービスで指定された名前に変更可能。
`licensedStylesheet` は正規配信のCSS URL、`titleImage` は正規に作成したタイトル画像のURL。
原稿用標準書体: https://booth.pm/ja/items/2021188 商用利用記載はあるがWeb埋め込みの明示許諾は未確認。許諾確認または正規タイトル画像が必要。
あおとゴシック: https://morisawafonts.com/plans/webfont/ 正規Webフォント契約・配信設定が必要。デスクトップ用OTFはアップロードしない。

# 検証範囲
node checks.mjs / node flow-check.mjs: 実際のThree.jsの行列・レイ判定と状態遷移。WebGLRendererのみモック。
この環境に対応ブラウザQAがないため、GPU描画の目視検証は未実施。展示用PCで比較ページ・全ルートの最終目視確認が必要。
